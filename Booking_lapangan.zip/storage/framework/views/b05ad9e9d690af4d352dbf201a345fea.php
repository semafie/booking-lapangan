
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card px-4 py-2 tab-pane "  id="navs-pills-top-aktif" role="tabpanel">

            <a href="" class="btn btn-primary my-3"
            style="display: inline-block; width: auto; max-width: fit-content;" data-bs-toggle="modal" data-bs-target="#tambahjadwal">
            Tambah Data Jadwal
        </a>
        
        <div class="text-nowrap table-responsive pt-0">
            <table id="myTable" class="datatables-basic table border-top">
                <thead>
                    <tr>
                        <th>Nama Lapangan</th>
                        <th>jam_mulai</th>
                        <th>jam_berakhir</th>
                        <th>status</th>
                        <th>Aksi</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->lapangan->nama); ?></td>
                            <td><?php echo e($item->jam_mulai); ?></td>
                            <td><?php echo e($item->jam_selesai); ?></td>
                            <td><?php echo e($item->status); ?></td>
                            <td>
                                <div class="d-flex gap-3">
                                    <button type="submit" class="btn btn-warning" data-bs-toggle="modal"
                                    data-bs-target="#editjadwal<?php echo e($item->id); ?>">Edit</button>
                                <form action="<?php echo e(route('delete_jadwal', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <input class="form-control" type="hidden" name="id_lapangan" value="<?php echo e($id_lapangan); ?>" id="html5-time-input" />
                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                </form>
                                </div>
                            </td>
                        </tr>

                        <div class="modal fade" id="editjadwal<?php echo e($item->id); ?>" aria-labelledby="modalToggleLabel" tabindex="-1" style="display: none;" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="modalToggleLabel">Edit Data Jadwal</h5>
                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="<?php echo e(route('edit_jadwal', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                <div class="modal-body">
                                   
                                    <label for="defaultFormControlInput" class="form-label">jam_mulai</label>
                                    <input class="form-control" type="hidden" name="id_lapangan" value="<?php echo e($id_lapangan); ?>" id="html5-time-input" />
                                    <input class="form-control" type="time" name="jam_mulai" value="<?php echo e($item->jam_mulai); ?>" id="html5-time-input" />
                                    <label for="defaultFormControlInput" class="form-label">jam_selesai</label>
                                    <input class="form-control" type="time" name="jam_selesai" value="<?php echo e($item->jam_selesai); ?>" id="html5-time-input" />
                                    
                                </div>
                                <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary" data-bs-toggle="modal" data-bs-dismiss="modal">Edit Data</button>
                                </div>
                            </form>
                              </div>
                            </div>
                          </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="modal fade" id="tambahjadwal" aria-labelledby="modalToggleLabel" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="modalToggleLabel">Tambah Data Jadwal</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('tambah_jadwal')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="modal-body">
                   
                    <label for="defaultFormControlInput" class="form-label">jam_mulai</label>
                    <input class="form-control" type="hidden" name="id_lapangan" value="<?php echo e($id_lapangan); ?>" id="html5-time-input" />
                    <input class="form-control" type="time" name="jam_mulai" value="12:30:00" id="html5-time-input" />
                    <label for="defaultFormControlInput" class="form-label">jam_selesai</label>
                    <input class="form-control" type="time" name="jam_selesai" value="12:30:00" id="html5-time-input" />
                    
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary" data-bs-toggle="modal" data-bs-dismiss="modal">Tambah Data</button>
                </div>
            </form>
              </div>
            </div>
          </div>

    </div>
</div>

<script>
    <?php if(Session::has('berhasil_tambah')): ?>
  
    Swal.fire({
      title: 'Berhasil',
      text: 'Data Berhasil ditambahkan',
      icon: 'success',
      confirmButtonText: 'Oke'
    })
  
    <?php elseif(Session::has('gagal_tambah')): ?>
    Swal.fire({
      title: 'Gagal',
      text: 'Data gagal di tambahkan',
      icon: 'error',
      confirmButtonText: 'Oke'
    })
  
    <?php elseif(Session::has('berhasil_edit')): ?>
  
    Swal.fire({
      title: 'Berhasil',
      text: 'Data Berhasil di edit',
      icon: 'success',
      confirmButtonText: 'Oke'
    })
  
    <?php elseif(Session::has('berhasil_hapus')): ?>
  
    Swal.fire({
      title: 'Berhasil',
      text: 'Data Berhasil dihapus',
      icon: 'success',
      confirmButtonText: 'Oke'
    })
  
    <?php elseif(Session::has('kosong_tambah')): ?>
  
    Swal.fire({
      title: 'Gagal ',
      text: 'Lengkapi data',
      icon: 'error',
      confirmButtonText: 'Oke'
    })
    <?php endif; ?>
  
     </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RESTU\Documents\restu\kerja\joki\Booking_lapangan\resources\views/admin/pages/jadwal/jadwal.blade.php ENDPATH**/ ?>
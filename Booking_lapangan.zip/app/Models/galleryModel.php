<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class galleryModel extends Model
{
    protected $table = 'gallery';

    protected $fillable = [
        'gambar',

    ];
}
